import * as THREE from "three"; //Calls on the Three plug-in
import { GLTFLoader } from "three/examples/jsm/loaders/GLTFLoader.js";
import * as Tone from "tone"; //Calls on the Tone plug-in
import { OrbitControls } from "three/examples/jsm/controls/OrbitControls.js";
import "./styles.css"; //Links the javascript file to the css file
import { AudioLoader } from "three"; //Importing the audioloader function from three.js
import * as TILT from "vanilla-tilt"; //Calls on the tilt plug-in

//Light & Scene
let scene, camera, renderer;
let colour, intensity, light, ambientLight;
let nextColour;
let sceneHeight, sceneWidth;
let clock, delta, interval;
let orbit;

//Sound
let daySong, nightSong, nightLoaded, dayLoaded;
let soundBoat, soundCaravan, soundPlane;
let listener, audioLoader, audioLoader2;
listener = new THREE.AudioListener();
daySong = new THREE.Audio(listener);
nightSong = new THREE.Audio(listener);
soundBoat = new THREE.Audio(listener);
soundCaravan = new THREE.Audio(listener);
soundPlane = new THREE.Audio(listener);
audioLoader = new THREE.AudioLoader();
audioLoader2 = new THREE.AudioLoader();

//Raycasting
let mouse, raycaster;
let boatDown, boatIntersects;
let caravanDown, caravanIntersect;
let planeDown, planeIntersects;

//Models
let planet, boat, caravan, plane;
let boatGeometry, planeGeometry, caravanGeometry;
let boatMaterial, planeMaterial, caravanMaterial;
let cube, cube2, cube3;
let modelLoaded, loader;

//Model Controls
let time = true;
let prevAngle = 180;
let totalAngle = 0;

//Initiate
let startButton = document.getElementById("startButton"); //Setting variable to call upon the html button id startbutton
startButton.addEventListener("click", init); //When the start button is clicked it initiates the init function

function init() {
  // remove overlay
  let overlay = document.getElementById("overlay");
  overlay.remove();

  //Raycasting
  boatDown = false;
  caravanDown = false;
  planeDown = false;

  raycaster = new THREE.Raycaster();
  mouse = new THREE.Vector2();

  boatIntersects = [];
  caravanIntersect = [];
  planeIntersects = [];

  //Models
  modelLoaded = false;
  loadModels();

  //create our clock and set interval at 30 fpx
  clock = new THREE.Clock();
  delta = 0;
  interval = 1 / 25;

  //create our scene
  sceneWidth = window.innerWidth;
  sceneHeight = window.innerHeight;
  scene = new THREE.Scene();
  scene.background = new THREE.Color(0x5dfff8); //Background Colour (Day time)

  //create camera
  camera = new THREE.PerspectiveCamera(
    75,
    window.innerWidth / window.innerHeight,
    0.1,
    1000
  );
  camera.position.x = 0; //Starting camera position on X axis
  camera.position.y = 0; //Starting camera position on Y axis
  camera.position.z = 17; //Starting camera position on Z axis

  //specify our renderer and add it to our document
  renderer = new THREE.WebGLRenderer({ antialias: true });
  renderer.setSize(window.innerWidth, window.innerHeight);
  document.body.appendChild(renderer.domElement);

  //create the orbit controls instance so we can use the mouse move around our scene
  orbit = new OrbitControls(camera, renderer.domElement);
  orbit.enableZoom = false; //Stops zoom
  orbit.maxPolarAngle = Math.PI / 2; //Stops rotation on y axis
  orbit.minPolarAngle = Math.PI / 2; //Stops rotation on y axis

  // lighting
  colour = 0xffffff; //White light
  intensity = 0.7; //Brightness of light

  //Ambient Lighting
  ambientLight = new THREE.AmbientLight(colour, 1); //Light for the whole scene and the intensity of it
  scene.add(ambientLight); //Adding the ambient light to the scene

  //Front Light
  light = new THREE.DirectionalLight(colour, intensity); //Adding a light from a set location using the white colour and intensity set earliers
  light.position.set(-1, 2, 4); //Position of the directional light
  scene.add(light); //Adding the directional light to the scene

  //Back Light
  light = new THREE.DirectionalLight(colour, intensity); //Adding a light from a set location using the white colour and intensity set earliers
  light.position.set(1, -2, -4); //Position of the directional light - opposite to the other directional light to create a backlight
  scene.add(light); //Adding the backlight to the scene

  //Cubes - used for wrapping around the models to make them easily accessible to click later in the code
  //Boat Cube - this cube will overlay the boat
  boatGeometry = new THREE.BoxGeometry(3, 3, 5); //Dimensions of the box by x,y,z axis
  boatMaterial = new THREE.MeshPhongMaterial({
    transparent: true, //Making the cube no longer visible
    opacity: 0
  });
  cube = new THREE.Mesh(boatGeometry, boatMaterial); //Making the cube mesh with the settings just stated
  //Position of cube
  cube.position.x = 5;
  cube.position.y = 6;
  cube.position.z = -2;
  scene.add(cube); //Adding the cube to the scene

  //Caravan Cube - this cube will overlay the caravan
  caravanGeometry = new THREE.BoxGeometry(4, 3, 3); //Dimensions of the box by x,y,z axis
  caravanMaterial = new THREE.MeshPhongMaterial({
    transparent: true, //Making the cube no longer visible
    opacity: 0
  });
  cube2 = new THREE.Mesh(caravanGeometry, caravanMaterial); //Making the cube mesh with the settings just stated
  //Position of cube2
  cube2.position.x = -5;
  cube2.position.y = 6;
  cube2.position.z = -3;
  scene.add(cube2); //Adding cube2 to the scene

  //Plane Cube - this cube will overlay the plane
  planeGeometry = new THREE.BoxGeometry(4.5, 3, 4); //Dimensions of the box by x,y,z axis
  planeMaterial = new THREE.MeshPhongMaterial({
    transparent: true, //Making the cube no longer visible
    opacity: 0
  });
  cube3 = new THREE.Mesh(planeGeometry, planeMaterial); //Making the cube mesh with the settings just stated
  //Position of cube3
  cube3.position.x = 0;
  cube3.position.y = 6;
  cube3.position.z = 4;
  scene.add(cube3); //Adding cube3 to the scene

  //Day song
  dayLoaded = false; //Setting the value to false
  audioLoader.load("./music/Summertime1.mp3", function (buffer) {
    //Loading the song
    daySong.setBuffer(buffer);
    daySong.setVolume(0.5); //Setting the volume from the song - ranges from 0-1
    daySong.setLoop(true); //The song will loop once finished
    dayLoaded = true; //Setting the previous value to true
  });

  //Night song
  nightLoaded = false; //Setting the value to false
  audioLoader2.load("./music/WarmDaydream.mp3", function (buffer) {
    //Loading the song
    nightSong.setBuffer(buffer);
    nightSong.setVolume(0.5); //Setting the volume from the song - ranges from 0-1
    nightSong.setLoop(true); //The song will loop once finished
    nightLoaded = true; //Setting the previous value to true
  });

  //Boat SFX
  audioLoader.load("./SFX/BoatHorn.mp3", function (buffer) {
    //Loading the sound for the boat
    soundBoat.setBuffer(buffer);
    soundBoat.setVolume(0.3); //Setting the volume from the song - ranges from 0-1
    soundBoat.setLoop(false); //The sound will not loop once finished - only play once until called again
  });

  //Caravan SFX
  audioLoader.load("./SFX/Engine.mp3", function (buffer) {
    //Loading the sound for the caravan
    soundCaravan.setBuffer(buffer);
    soundCaravan.setVolume(0.75); //Setting the volume from the song - ranges from 0-1
    soundCaravan.setLoop(false); //The sound will not loop once finished - only play once until called again
  });

  //Plane SFX
  audioLoader.load("./SFX/Spitfire.mp3", function (buffer) {
    //Loading the sound for the plane
    soundPlane.setBuffer(buffer);
    soundPlane.setVolume(0.75); //Setting the volume from the song - ranges from 0-1
    soundPlane.setLoop(false); //The sound will not loop once finished - only play once until called again
  });

  window.addEventListener("pointermove", move, false); //Adding a move event for the mouse - currently not in use
  window.addEventListener("pointerdown", triggerAttack, false); //Adding a click event - currently not in use
  window.addEventListener("pointerup", triggerRelease, false); //Adding a release of click event - currently not in use
  window.addEventListener("resize", onWindowResize, false); //resize callback

  play();
}

function loadModels() {
  //Loading Screen
  let loadingManager = new THREE.LoadingManager();
  let progressBar = document.getElementById("progress-bar"); //Calling upon css and html
  loadingManager.onProgress = function (url, loaded, total) {
    progressBar.value = (loaded / total) * 100; //Adding progress towards the bar and displaying the progress
  };

  let progressBarContainer = document.querySelector(".progress-bar-container"); //Calling upon css and html
  loadingManager.onLoad = function () {
    progressBarContainer.style.display = "none"; //Removes the loading bar once finished
  };
  loader = new GLTFLoader(loadingManager);

  //Settings for models
  //Planet
  const setPlanet = function (gltf, position) {
    planet = gltf.scene.children[0];
    planet.scale.multiplyScalar(4); //Size of model
    planet.position.copy(position);
    modelLoaded = true;
    scene.add(planet); //Adds the model to the scene
  };

  //Boat
  const setBoat = function (gltf, position) {
    boat = gltf.scene.children[0];
    boat.scale.multiplyScalar(0.3); //Size of model
    boat.position.copy(position);
    modelLoaded = true;
    scene.add(boat); //Adds the model to the scene
  };

  //Caravan
  const setCaravan = function (gltf, position) {
    caravan = gltf.scene.children[0];
    caravan.scale.multiplyScalar(0.2); //Size of model
    caravan.position.copy(position);
    modelLoaded = true;
    scene.add(caravan); //Adds the model to the scene
  };

  //Plane
  const setPlane = function (gltf, position) {
    plane = gltf.scene.children[0];
    plane.scale.multiplyScalar(0.005); //Size of model
    plane.position.copy(position);
    modelLoaded = true;
    scene.add(plane); //Adds the model to the scene
  };

  //Setting positions
  const planetPos = new THREE.Vector3(0, -1, 0); //Planet position
  const boatPos = new THREE.Vector3(5, 6, -4); //Boat position
  const caravanPos = new THREE.Vector3(-5, 6, -3); //Caravan position
  const planePos = new THREE.Vector3(0, 6.3, 4); //Plane position

  //Loading the Models into the scene
  //load planet
  loader.load("planet/planet.gltf", function (gltf) {
    setPlanet(gltf, planetPos);
  });

  //load boat
  loader.load("boat/scene.gltf", function (gltf) {
    setBoat(gltf, boatPos);
  });

  //load caravan
  loader.load("caravan/scene.gltf", function (gltf) {
    setCaravan(gltf, caravanPos);
  });

  //load plane
  loader.load("plane/scene.gltf", function (gltf) {
    setPlane(gltf, planePos);
  });
}

// simple render function
function render() {
  renderer.render(scene, camera);
}

// start animating
function play() {
  //using the new setAnimationLoop method which means we are WebXR ready if need be
  renderer.setAnimationLoop(() => {
    update();
    render();
  });
}

//our update function
function update() {
  orbit.update();
  //Converting radians to degrees
  let AngleDegrees = (180 / Math.PI) * orbit.getAzimuthalAngle() + 180;

  let changeAngle = Math.abs(AngleDegrees - prevAngle); //Numbers cannot go into the negatives
  if (changeAngle > 360) {
    changeAngle += 360;
  } else if (totalAngle > 360) {
    scene.background = nextColour; //Changes the background colour to the next colour stated by nextColour
    totalAngle = 0; //Resets the totalAngle to 0
    time = !time; //Sets time to no longer be the original value
  }

  totalAngle += changeAngle;
  prevAngle = AngleDegrees;

  if (dayLoaded && nightLoaded) {
    if (time === true) {
      nextColour = new THREE.Color(0x434242); //When time is equal to true the background colour is the day colour

      if (nightSong.isPlaying) nightSong.stop(); //If the night song is playing its to stop
      if (daySong.isPlaying === false) {
        //If day song equals false day song starts playing
        daySong.play();
      }
    } else if (time === false) {
      //When time is equal to false the background colour is dark for night
      nextColour = new THREE.Color(0x5dfff8);
      if (nightSong.isPlaying) daySong.stop(); //If night song is called the day song stops
      if (nightSong.isPlaying === false) {
        //If night song equals false night song starts playing
        nightSong.play();
      }
    }
  }
  //update stuff in here
  delta += clock.getDelta();
  if (delta > interval) {
    delta = delta % interval;
  }
}

function onWindowResize() {
  //resize & align
  sceneHeight = window.innerHeight;
  sceneWidth = window.innerWidth;
  renderer.setSize(sceneWidth, sceneHeight);
  camera.aspect = sceneWidth / sceneHeight;
  camera.updateProjectionMatrix();
}

function triggerAttack(event) {
  raycaster.setFromCamera(mouse, camera); // create our ray
  boatIntersects = raycaster.intersectObject(cube); //Boat intersect is raycasting for cube
  caravanIntersect = raycaster.intersectObject(cube2); //Caravan intersect is raycasting for cube2
  planeIntersects = raycaster.intersectObject(cube3); //Plane intersect is raycasting for cube3

  //Testing to see if mouse clicks on the cube
  if (boatIntersects.length > 0) {
    //If the mouse clicks on cube then boatDown is equal to being true
    boatDown = true;
  }
  if (caravanIntersect.length > 0) {
    //If the mouse clicks on cube2 then caravanDown is equal to being true
    caravanDown = true;
  }
  if (planeIntersects.length > 0) {
    //If the mouse clicks on cube3 then planeDown is equal to being true
    planeDown = true;
  }

  //Cubes are clicked
  if (boatDown) {
    //If the boat is clicked the sound for the boat plays
    soundBoat.play();
  }
  if (caravanDown) {
    //If the caravan is clicked the sound for the caravan plays
    soundCaravan.play();
  }
  if (planeDown) {
    //If the plane is clicked the sound for the plane plays
    soundPlane.play();
  }
}

function move(event) {
  mouse.x = (event.clientX / sceneWidth) * 2 - 1; // convert our mouse x position to be a value between -1.0 and 1.0
  mouse.y = -(event.clientY / sceneHeight) * 2 + 1; // convert our mouse y position to be a value between -1.0 and 1.0
}

function triggerRelease() {
  //Setting mouse clicks to false when the mouse is no longer clicking the corresponding cube
  boatDown = false;
  planeDown = false;
  caravanDown = false;
}
